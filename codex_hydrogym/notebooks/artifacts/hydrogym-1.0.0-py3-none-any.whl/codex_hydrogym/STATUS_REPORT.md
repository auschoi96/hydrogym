<!-- footer Databricks | codex_hydrogym | Implementation pause report -->
<!-- toc -->

# codex_hydrogym — Current Status and Evidence-Gate Report

**Status date:** August 25, 2026

**Workspace profile:** `dais-demo`

**Project label:** `codex_hydrogym`

**Current state:** The reward/reviewer loop is causally wired and locally tested, but scientific Gate 0 still fails after two frozen protocols. Re=100 v2 passed development and every held-out primary causal gate, then failed the preregistered temporal and spatial convergence gates. A subsequent fresh-seed, development-only ensemble diagnostic passed every causal, numerical, and point-convergence check but missed both uncertainty-aware effect-equivalence checks; it does not rescue v2 or authorize a full Gate 0 v3. A separate ten-new-seed replication-sizing protocol is now frozen, but it has no condition artifacts and has executed zero CFD trajectories pending explicit CPU confirmation. Direct-critic transport is proven on one synthetic bundle only. No PPO, GEPA, MemAlign training, measured coding-agent revision screen, or contained-App deployment is authorized by this report.

## Executive summary

The `codex_hydrogym` software and Databricks App foundation exists: a JAX Kolmogorov-flow path, PPO training code, deterministic reward compilation, MLflow tracking, a registered coding-agent revision prompt, human-review surfaces, Unity Catalog model-registration guards, and an AppKit visualization. Those components are useful infrastructure, but they do not establish that the current control problem is scientifically suitable for reinforcement learning or that model feedback improves it.

The confounded original task has been repaired enough to execute a preregistered CPU gate: the control curl now has the missing `2πi` derivative factor, the forcing has episode-specific phase, the forced mode has sine/cosine quadrature actuation, signed modal observations are versioned, and the evaluator includes phase/seed pairing plus an observation-derangement ablation. Those changes do not make the task valid by themselves. Frozen Gate 0 v1 fails at Re=200 and `48×48` because its maximum retained spectral-tail fraction was `0.082028`, above the locked `0.05` limit. A separately frozen Re=100 v2 at primary `64×64`, temporal `dt=0.001`, and spatial `96×96` passed development and all 20 primary causal/numerical gates. It nevertheless failed six of ten final convergence gates: maximum arm changes were `8.07%` temporally and `5.38%` spatially, and maximum relative-effect drifts were `0.05365` and `0.04249`, above their locked limits. The prior one-case Re=100 probe was therefore optimistic. A later four-seed ensemble screen found stable point estimates but could not establish temporal or spatial effect equivalence inside the unchanged margins. A prospectively fixed ten-seed replication is prepared only to test that seed-level uncertainty as a separate development sample; freezing it produces no new result. The held-out RL comparison remains blocked.

The architecture remains ordered as:

`passing CPU Gate 0 → repair the signed, phase-randomized PPO/evaluation contract → measured MLflow RunBundles → one Codex RewardSpec draft → base-versus-MemAlign reviewer advice → same-Codex paired revisions → human critic_quality labels and held-out reviewer evaluation → human approval → deterministic reward compilation → one bounded RL trial`

This remains a hypothesis, not a result, and there is no currently authorized path past its first step. Codex is the first coding-agent harness because its local transport passed and a single harness makes the paired reviewer experiment cheaper and cleaner. MemAlign may align only the composite `critic_quality` reviewer: it measures agreement with expert judgment, never fluid performance. HydroGym computes the approved reward deterministically during training; the coding agent never executes reward code in the environment. A small coefficient grid is the required cheap control. Claude and GEPA are optional later cost/quality benchmarks only if Codex plus the hand-written prompt measurably helps on held-out human judgments.

## Live resources

Read-only workspace inspection authenticated successfully with profile `dais-demo` on August 24, 2026.

| Resource | Identifier | Current status |
|---|---|---|
| Databricks App | [codex_hydrogym control cockpit](https://codex-hydrogym-7474647489683936.aws.databricksapps.com) | `ACTIVE`, but its UI still advertises the obsolete bootstrap → MemAlign → GEPA → H100 sequence |
| MLflow experiment | `/Shared/codex_hydrogym` — `103455306564903` | Contains the finished transport-only P0 run plus two historical H100 setup failures; no PPO/fluid result |
| UC revision prompt | `prompts:/austin_choi_omni_agent_catalog.codex_hydrogym.codex_hydrogym_reward_revision/1` | Registered and verified; alias `baseline`; not yet consumed by a measured remote revision run |
| Feedback bootstrap job | `528338478292601` | Bound to the app; zero runs; earlier proposal-feedback path |
| MemAlign job | `1046052441090117` | Bound to the app; zero runs; legacy `fluid_reward_plausibility` definition, so do not run it as the current `critic_quality` workflow |
| GEPA job | `264942649048223` | Bound to the app; zero runs; legacy resource excluded from the MVP |
| Reusable H100 PPO job | `365523074984029` | Bound to the app; zero runs; do not run before Gate 0 passes |
| Historical H100 job run | `366806901874578` from deleted job `278222053449531` | Failed during setup before user code; not a baseline result |
| Registered model target | `austin_choi_omni_agent_catalog.codex_hydrogym.codex_hydrogym_ppo_controller` | No eligible version registered yet |

## Work completed

### HydroGym and PPO execution path

- Added a labeled `codex_hydrogym` training package around HydroGym's JAX Kolmogorov-flow environment.
- Implemented a bounded PPO configuration, rollout/training loop, checkpoints, validation artifacts, and deterministic numerical and physics gates.
- Built a bounded H100 workload path, now held behind the cheaper CPU scientific gate described below.
- Tagged baseline and aligned runs separately while keeping both in the same MLflow experiment.
- Required matching evaluation-context fingerprints before baseline-versus-aligned comparisons are considered valid.
- Added a separate frozen-training fingerprint that includes optimizer, rollout, seed, and budget fields while excluding only reward choice and run labeling.
- Added a deterministic reward wrapper around the existing HydroGym metrics. The executable v2 formula is `-TKE/E_ref - λu·||a||₁/2 - λΔ·||a-a_prev||²/4`.

This path is not ready to run the repaired task. The PPO defaults still use one fixed forcing phase and the legacy `8×8` speed-grid observation, while Gate 0 uses phase-sensitive signed forced-mode observations. The policy packaging and serving signature also hardcode `obs_size**2` inputs, so changing training to the signed two-value observation would currently break model registration. A Gate 0 pass would authorize repairing and testing these contracts, not launching the existing H100 job.

### MLflow reproducibility and Unity Catalog

- Consolidated all PPO, human feedback, judge alignment, GEPA, and promotion work into the one managed experiment `/Shared/codex_hydrogym`.
- Added a regression test that fails if alignment jobs or the App stop using that single experiment resource.
- Added MLflow parameters, step metrics, physics-gate metrics, tags, checkpoints, and evidence artifacts to the training path.
- Implemented a custom MLflow policy-model packaging and Unity Catalog registration path.
- Registration and the `candidate` alias occur only after deterministic physics validation passes.
- The production-promotion reader now rejects `train/*` curves and unfinished runs and requires separately named `heldout/*` metrics, matching SHA-256 evaluation-context and frozen-training fingerprints, and a lowercase SHA-256 `heldout_evidence_digest`. Prompt and model promotion enforce the same frozen-training parity, model-version metadata carries the frozen-training fingerprint, verified promotion tags are written before the serving-impacting alias, and the alias mutation is last. No current evaluator computes and logs those metrics plus digest-bound protocol provenance, so production promotion remains fail-closed and unusable by design. Digest syntax alone is not artifact verification; the separate held-out evaluator must compute and independently verify the digest from its immutable evidence artifact, bind its separate evaluation run to the exact trained checkpoint/model version, and cross-check the logged metrics.
- RewardSpec v2 contains only `control_l1_weight ∈ [0.05, 1]` and `action_delta_l2_weight ∈ [0, 0.25]`, plus formula/evidence identity. PPO optimizer and compute settings are forbidden.
- Reward compilation binds the model proposal to development-only `E_ref`, calibration evidence, human approval, and canonical digests. AI Runtime rejects an `aligned` run unless its materialized PPO config exactly matches that compiled manifest; a prompt tag alone cannot unlock training.
- Removed the accidental extra experiment from active use; it was moved to MLflow Trash.

### Human-feedback and coding-agent revision path

- Retained the earlier proposal/GEPA assets as legacy, non-authorizing infrastructure.
- Added a strict reward-only AgentFeedback v2 contract while preserving a read-only parser for archived RewardSpec v1 outputs.
- Implemented `initial Codex draft → reviewer advice → same Codex model/adapter revision`, with one exact draft reused across base and aligned reviewer arms.
- Bound each reviewer assessment to the RunBundle evidence digest and exact initial-draft digest. Cross-bundle, cross-draft, changed-model, and changed-adapter revisions fail closed.
- Registered the prompt the coding agent actually consumes and traced requested/resolved prompt URI, version, template digest, rendered digest, draft digest, reviewer digest, treatment, model, and adapter.
- Fixed AI Runtime prompt validation so the exact fully qualified UC URI for that registered revision prompt is accepted while a foreign or unlabeled prompt leaf still fails closed.
- Added the exact `critic_quality` labeling-session and one-consensus-HUMAN-label helpers, disjoint-fold checks, Codex-only MemAlign support, and a helper that registers the aligned scorer as a new version rather than replacing the base scorer.
- Kept promotion separate from reviewer alignment so an improved judge or revision cannot claim fluid-control benefit without held-out RL evidence and deterministic physics gates.

The MVP does not run GEPA. MemAlign must not overwrite a shared scorer or align on every labeled trace. It may train only on a locked critic-quality training fold, leave a grouped held-out fold untouched, and align the single adjudicated 1–5 `critic_quality` assessment. There are currently zero eligible labels and zero usable native remote measured traces, so a meaningful MemAlign call would be invalid.

The local reward path is now causally connected: a bounded RewardSpec can compile into the deterministic wrapper only after evidence calibration and human approval, and AI Runtime verifies the matching manifest. This proves wiring, not usefulness. No measured coding-agent revision, approved manifest, PPO run, or held-out evaluation has exercised that path. The legacy GEPA function still optimizes the older direct reward-student prompt, not the registered coding-agent revision prompt, and therefore remains outside the current experiment.

An independent fail-closed audit found that this is still prototype wiring rather than a trustworthy executable loop: the current `align` CLI/job invokes the legacy `fluid_reward_plausibility` path rather than the new `critic_quality` function; train/held-out isolation is not revalidated by `group_id` and `critic_fold` inside the alignment function; reviewer advice and resolved-prompt lineage are not re-read from MLflow; and approval/calibration digests remain caller assertions rather than independently verified HUMAN and calibration artifacts. Those gaps must be resolved before the first measured reviewer experiment, but implementing the full provenance service before Gate 0 would be premature.

### Current direct-critic direction

- GPT and Claude receive the byte-identical canonical `RunBundle` prompt through a no-tool direct Databricks AI Gateway adapter and return the same strict `AgentFeedback` schema.
- The direct adapter forwards a strict structured-output schema, records the reported model and finish reason, and accepts only an exact configured model ID or an explicitly supplied provider alias; it fails closed on missing or unexpected reported-model IDs and on response, arm, adapter, or feedback-identity mismatches.
- MLflow tracing uses an `AGENT` root span with `harness_call` and contract-validation child spans. Adapter identity is first-class provenance.
- Managed-dataset records now require a native top-level `TRACE` source and distinct trace IDs. Publication verifies that every trace is readable, belongs to the target experiment, has state `OK`, has the expected sole `AGENT` root, and agrees exactly with the record's trace provenance, RunBundle, and outputs. Paired records use arm-scoped opaque input IDs; the four-adapter screen uses adapter-scoped IDs. A local SQLite MLflow round-trip proved four adapter records remain trace-sourced and idempotent.
- Held-out critic reporting has only claim-scoped metrics: mean absolute error, tie-aware Spearman correlation, and within-bundle GPT-versus-Claude preference agreement. These quantify critic alignment, not fluid control.
- The offline sanity corpus remains synthetic and cannot enter a non-sanity fold. No 20-call screen, human labeling set, or MemAlign alignment has run.
- The AppKit review route and library helpers now use the exact `critic_quality` target, but no measured trace is eligible for review. The revision loop is locally integrated and traced; it has not run against the remote registered prompt or produced quality evidence.
- Direct Gateway critics remain a cheaper transport baseline. The first measured reviewer-revision experiment uses Codex only; adding Claude is justified only if there is a controlled incremental question.

### Proven P0 transport result

Read-only reinspection with profile `dais-demo` confirmed finished MLflow run [`b9908e32d1bb4cb4a633f10530f13bf5`](https://fevm-austin-choi-omni-agent.cloud.databricks.com/ml/experiments/103455306564903/runs/b9908e32d1bb4cb4a633f10530f13bf5) in experiment `103455306564903`.

| Adapter | Model | Result | Latency | Decision | Tool activity |
|---|---|---:|---:|---|---:|
| `codex_direct` | `system.ai.gpt-5-6-sol` | Strict contract passed | `9.693 s` | `stop` | `0` |
| `claude_direct` | `system.ai.claude-opus-5` | Strict contract passed | `23.025 s` | `stop` | `0` |
| `codex_sdk` | `gpt-5.6-luna`, `openai-codex==0.147.0` | Strict contract passed | `11.580 s` | `stop` | `0` |
| `claude_agent_sdk` | `databricks-claude-sonnet-4-6[1m]`, SDK `0.2.142` | Failed closed on unexpected `HookEventMessage` | — | — | rejected |

The two direct calls used prompt SHA-256 `98e95a5d73808c6c64c4b5b726cbe6b58d14c496696d0ebe7b12b6bfc774d8d1`, a `4,096` token cap, the same strict transport schema, and no tools. The provider-reported aliases were `gpt-5.6-sol` for `system.ai.gpt-5-6-sol` and `us.anthropic.claude-opus-5` for `system.ai.claude-opus-5`; future calls must opt into those exact aliases explicitly. The run stores `p0_manifest.json` and four serialized source-trace artifacts. It is durable transport evidence, but the serialized trace IDs came from a local MLflow store and are not retrievable as native traces in the remote experiment; the remote experiment currently returns zero native traces. Those artifacts therefore cannot be relabeled as remote `TRACE` dataset lineage. Future measured calls must trace directly to the target experiment, and publication now fails closed unless each source trace is readable, target-experiment-owned, successful, and consistent with its dataset record.

This P0 proves only that two direct model families can consume the same synthetic bundle and satisfy the contract. It does not measure critic quality, establish a controlled model comparison, validate MemAlign, justify GEPA, train RL, or show fluid improvement. The SDK models were also different revisions from the direct models, so the SDK follow-up is a system check rather than a transport-only model comparison. No further Claude SDK repair is planned for the MVP.

### Scientific Gate 0 currently fails

The original control confound is now represented by an executable, non-RL Gate 0 rather than hand-waved away:

- `control_term` applies the physical `2πi` spectral derivative and has manufactured sine/cosine regression coverage.
- The periodic grid excludes the duplicate endpoint and the dealiasing mask uses explicit integer Fourier modes.
- Episode forcing phase, forced-mode sine/cosine action channels, and signed forced-mode observations have versioned contracts.
- A development-only search locks the observation-free constant and signed-feedback gain before held-out cases are opened.
- Held-out arms compare zero, fixed constant, privileged phase oracle, signed feedback, and a whole-trajectory phase-and-seed derangement while preserving global observation/action marginals and effort.
- Final success fails closed until temporal and spatial refinement attestations are digest-bound to the exact primary artifact.

Frozen v1 protocol fingerprint `ab83f36f4ed9991320ac6e191bb6330d4c7fdc502430a4b65bf4c5fbbe598fd5` has multiple implementation attestations. The `c757978ca1e5…` directory is only a `frozen_before_execution` protocol artifact and must not be cited as the executed failure. The durable failed development search is `ab83f36f4ed9-c6c1c6002c25/development_search_failure.json`, with failure digest `c0be6dd593c948fd57437996f9f81274ce11c7e1736338d3c00e3c7346c80140`; it records `spectral_tail_controlled` failures for the attempted candidates/cases but, by the v1 schema, stores booleans rather than the numeric tail. The exact diagnostic rerun observed Re=200 `48×48` maximum retained tail `0.082028`, exceeding `0.05`. That numeric diagnosis is reproducible probe evidence, not a field in the durable v1 failure JSON.

The exact phase-0/seed-7 Re=200 probes were:

| Grid | Tail peak | Zero TKE | Gain-2 feedback TKE |
|---|---:|---:|---:|
| `48×48` | `0.082028` | `3.228788` | `2.450107` |
| `64×64` | `0.040299` | `3.070390` | `2.410477` |
| `96×96` | `0.006753` | `3.479144` | `2.508411` |

The Re=200 `64→96` comparison fails the locked convergence tolerances: zero-arm TKE changes `13.31%` against a `5%` limit, feedback TKE changes `4.06%`, and the effect changes `0.0641` against a `0.03` limit. The failure may combine spatial error with finite-window chaotic variability, but distinguishing those requires a costlier ensemble. Merely promoting the primary grid to `64×64` is not defensible.

Re=100 v2 was explicitly approved, separately frozen, and executed exactly once. Protocol `offset_phase_fp64_re100_gate0_v2` has fingerprint `2729e365a5712b824d4d1a2257ade19519aa454509a221790ddcabf2021b32a9`, implementation digest `5cc598c6b6e6168ec78d80360326d8d595ada81f4c9790b4d1c86b67f28350c4`, and immutable evidence directory `2729e365a571-5cc598c6b6e6`. It changed only the protocol ID, Reynolds number, primary grid, and spatial-refinement grid from v1; all phases, seeds, horizons, candidates, action/observation contracts, and causal/numerical/convergence limits were preserved. Two regression tests enforce that boundary.

Development passed and locked fixed action `(0.1767767, 0.1767767, 0, 0)` plus signed-feedback gain `2.0`, under lock digest `90c324567e20ab28cec778ad5d5dd53734619f2e04496046d9208e9c229e24df`. The full 12-cell held-out primary comparison then passed all 20 registered gates:

| Primary arm | Mean TKE | Mean RMS L2 effort |
|---|---:|---:|
| Privileged oracle | `0.729081` | `0.500000` |
| Signed feedback | `1.135629` | `0.334375` |
| Zero | `1.909851` | `0.000000` |
| Locked fixed | `1.912044` | `0.250000` |
| Observation deranged | `1.958062` | `0.334375` |

Signed feedback beat zero, fixed, and deranged controls in each independent held-out seed block. Its effort matched the deranged control exactly, global observation/action marginals matched, and every primary numerical gate passed. This primary evidence is bound by artifact digest `9ac1987e99bdaf7936a4c45047bf48d3e0df522bf95e22df1bf90b7edcbbc676`. It is a valid causal result inside the sampled primary evaluator, but it is not a final Gate 0 pass.

The digest-bound convergence stage was terminal:

| Refinement | Zero TKE, primary → refined | Feedback TKE, primary → refined | Max arm change | Limit | Max effect drift | Limit |
|---|---:|---:|---:|---:|---:|---:|
| Temporal, `dt 0.002 → 0.001` at `64×64` | `1.978711 → 1.818999` | `1.126668 → 1.133318` | `8.0715%` | `2%` | `0.053650` | `0.02` |
| Spatial, `64×64 → 96×96` at `dt=0.002` | `1.978711 → 1.872269` | `1.126668 → 1.145616` | `5.3793%` | `5%` | `0.042492` | `0.03` |

Both refinements passed numerical validity and preserved all ten materiality, opposite-phase, and effort decisions. Signed-feedback TKE itself changed only `0.5903%` temporally and `1.6818%` spatially. However, the frozen contract measures all arms and effects, not only the preferred controller. Both arm-convergence and effect-convergence gates failed, and exact ordering changed from `oracle < feedback < deranged < zero < fixed` to `oracle < feedback < zero < fixed < deranged`. The convergence attestation digest is `a7903f7fd7798118d6f27ace45cbaff043665d1aeee4f0a8fdd8ef6daa440d1d`; the final failed report digest is `e8a19fa835a991f233ed7087c31a7c947c6a61a9a3c04ceb935db2870f8dd463`.

A post-hoc case-level localization, which is diagnostic rather than decision evidence, found maximum per-phase TKE changes of `14.98%` temporal and `11.40%` spatial for the zero arm, versus `1.74%` and `4.62%` for signed feedback. The oracle also changed as much as `8.16%` in an individual spatial phase. Because all numerical gates passed, this pattern is more consistent with finite-window/discretization sensitivity across the benchmark than with a corrupt trace or solely an unstable feedback controller. It does not negate any failed preregistered gate.

The earlier phase-0/seed-7 Re=100 design probe had suggested spatial convergence, but it did not represent the full preregistered convergence case set and cannot override this executed result. Relaxing tolerances, dropping unstable arms, or retrying after seeing these results would be post hoc. Gate 0 v2 therefore fails honestly.

The gate deliberately uses a static phase within each episode. The primary pass establishes only sampled moderate-Re causal controllability; the failed convergence stage prevents a final scientific claim. Neither stage proves that PPO can infer a phase randomized inside vectorized resets, and neither performs RL.

### Fresh-seed ensemble diagnostic is promising but screen-negative

After the v2 failure was frozen, a separate exploratory protocol tested whether seed-clustered averaging and consecutive windows made the unchanged convergence margins plausible. This was not Gate 0 v3. Study `re100_fresh_seed_windowed_convergence_diagnostic_v1` used fresh development seeds `401`, `503`, `607`, and `709`; one opposite-phase pair; two consecutive 100-interval scoring windows; and only paired zero versus gain-2 signed-feedback arms. It evaluated the same base `64×64, dt=0.002`, temporal `64×64, dt=0.001`, and spatial `96×96, dt=0.002` conditions. Reserved phases and seeds were not opened. The claim boundary forbids treating the study as held-out, RL, coding-agent, MemAlign, GEPA, or fluid-improvement evidence.

| Condition | Zero mean TKE | Feedback mean TKE | Aggregate reduction | Seed-cluster effect 95% CI | Minimum block reduction |
|---|---:|---:|---:|---:|---:|
| Base | `1.869819` | `1.108867` | `40.6965%` | `[38.8662%, 42.2993%]` | `35.3819%` |
| Temporal | `1.871635` | `1.102617` | `41.0881%` | `[38.9286%, 43.0175%]` | `33.4377%` |
| Spatial | `1.939336` | `1.112311` | `42.6448%` | `[40.0240%, 45.1252%]` | `38.0000%` |

Signed feedback beat zero in all 48 seed × phase × window blocks, both consecutive-window mean effects exceeded the frozen `5%` materiality floor in every condition, every seed-cluster 95% CI was wholly above that floor, and all stored numerical gates passed. The point estimates also met all four old refinement checks:

| Refinement | Max arm difference | Arm limit | Aggregate effect difference | Effect limit | Paired-seed effect-difference 90% CI | Point checks | Equivalence CI |
|---|---:|---:|---:|---:|---:|---|---|
| Temporal | `0.5637%` | `2%` | `0.3915 pp` | `2 pp` | `[-1.7387, +2.5192] pp` | Pass | **Fail** |
| Spatial | `3.7179%` | `5%` | `1.9483 pp` | `3 pp` | `[+0.3957, +3.5879] pp` | Pass | **Fail** |

The result is therefore narrow but unambiguously negative under its frozen rule: only `temporal_effect_equivalence_ci_supported` and `spatial_effect_equivalence_ci_supported` were false, so `supports_designing_full_gate=false`. The temporal interval exceeded its upper equivalence margin by `0.5192` percentage points, and the spatial interval exceeded its upper margin by `0.5879` percentage points. This changes the diagnosis from obvious point nonconvergence to unresolved seed-level uncertainty; it does not establish equivalence, reverse the v2 failure, or prove that four seeds were sufficient.

The study fingerprint is `19927dd9f42cdcda5a7faf938a1a9da7814e4bb3031a1f15b08670ece6dd6caf`, its implementation digest is `0df64047e2c1372b79fb92420c2c99f75213f3386c1fc06767cd31f203de674b`, and its immutable evidence directory is `19927dd9f42c-0df64047e2c1`. The result digest is `e45eb7f6b19b52d6580462ef22e0efcc87a6cd435916f88694ef25e375777d9b`. A no-simulation round trip and an independent audit reproduced the analysis; validated all five artifact digests, all seven frozen implementation hashes, all 48 traces, and all 48 paired blocks; and confirmed the links to the v2 protocol and failed final report.

Appending cases to this completed study or promoting its passing point estimates after seeing the confidence-interval misses would be post hoc. If further fluid work is chosen, the next defensible step is a separately frozen replication-sizing diagnostic with new development seeds, a predeclared sample size, the same margins, and the reserved cases still sealed—not PPO or an automatic Gate 0 v3.

### Ten-seed replication protocol is frozen but unexecuted

The separate study `re100_fresh_seed_windowed_convergence_replication_v1` is implemented in `codex_hydrogym/gate0/ensemble_replication.py` and frozen at `codex_hydrogym/evidence/ensemble_replication/269507101a52-a5ab894e5ff4`. The directory contains only `protocol.json`: no base, temporal, spatial, or result artifact exists, and no CFD trajectory has run.

- Study fingerprint: `269507101a5206fccab3c90504f7a46009f28381070a0d97875a06429fb19b62`
- Implementation digest: `a5ab894e5ff4d3b669da274771f247e58f06aab992873fc9fe76dfdcf8622d8c`
- Protocol artifact digest: `3914aedc99979693bf693772a56eef83c3c242c6cd72dc7fda8c07583d781c87`
- New development seeds: `1100085772, 619716833, 1680869979, 270788329, 1326527252, 625393611, 901546380, 1422036434, 373522063, 1374108181`
- Sealed cases preserved: seeds `907, 1009`; phases `0.1875, 0.6875`
- Fixed workload: `3 conditions × 10 seeds × 2 phases × 2 arms = 120` trajectories

The seeds are the first ten eligible values from a frozen SHA-256 counter derivation after excluding all v1/v2, prior-diagnostic, and reserved seeds. The protocol retains Re=100 float64, phases `0.0625, 0.5625`, the 100-interval uncontrolled burn-in, 50-interval controller warmup, two 100-interval scoring windows, zero and gain-2 signed-feedback arms, the `0.5` radial bound, all three grids/time steps, all numerical and materiality gates, the `2%/2 pp` temporal margins, the `5%/3 pp` spatial margins, and the same point and uncertainty-aware screening predicates. The prior four observations are planning context only and are explicitly excluded from the replication analysis.

Execution is fail-closed unless the exact protocol already exists. It is resumable only by whole immutable condition artifacts, and its loader independently validates artifact/source identities, exact cases and arms, numerical-gate schema, interval/window reproduction and continuity, and paired initial/control-start states. The protocol artifact and all eight implementation hashes round-tripped independently. Seven new focused tests and all 247 scoped Python tests pass. This is preregistration infrastructure, not evidence that equivalence or Gate 0 passes; explicit confirmation is still required before the CPU run.

### Measured-local diagnostic, not a result claim

A sibling repaired tree at commit `f5eadecb2de4dc2812c7988adca5ce8bfd6b51e6` produced one useful CPU diagnostic with `dt=0.002`, seed 0, and a 512-step horizon:

| Controller | Settled TKE |
|---|---:|
| Zero action | `3.1696414947509766` |
| Constant opposition | `1.2599737644195557` |

The recorded fractional reduction was `0.6024869795192577`. The results record had SHA-256 `2c43041be0c1ad93f1fa1b0cb7523e86dfbb09b92af995be65397dd8aa0c69ce`.

This is diagnostic support for the fixed-forcing confound, not reproducible project evidence: it came from a different source tree, covered one seed, has no surviving raw log or MLflow run, and did not record the complete gate. It cannot support a fluid-improvement, RL, agent, MemAlign, or GEPA claim.

### Authenticated sibling GEPA/PPO evidence, not transferable to this lane

The supplied [GEPA review write-up](https://docs.google.com/document/d/16FWnnPpWN8oPsfGdRc9vQbXHmNXulgXMjvy8U1Euapk/edit) concerns the separate `claude_hydrogym` experiment `103455306563514`, not this project's experiment or current source tree. Read-only inspection with `dais-demo` nevertheless confirmed its central failure evidence:

- Finished PPO run `3954116690174b9492580de35267bc78` logged settled TKE `3.3466436863` for zero action, `1.2490334511` for constant opposition, and `1.4402053356` for the shipped learned policy. Its `tke_reduction_vs_oppose=-0.1530558564`, so the learned policy was 15.3% worse than constant opposition even though it beat zero action. The evaluation window was marked settled, but this was one training seed and lacks the current effort/phase protocol.
- GEPA job run `1027411304349635` and MLflow run `774fe7bcc5404cf6810c19f14bb820c9` were canceled after four proxy rounds, so they produced no final GEPA controller comparison.
- The four eight-seed proxy-round means for `tke_reduction_vs_zero` were `0.08979`, `0.08881`, `0.09508`, and `0.09241`. Their standard errors were `0.00658`, `0.01036`, `0.01109`, and `0.01226`; the full spread between round means was only `0.00627`. All 32 child trials logged `beats_oppose=0`.

This sibling result does not establish that GEPA fails generally, because its proxy, seeds, task formulation, and code are not the current protocol. It does show that the available GEPA run supplied no detectable benefit and ranked differences no larger than its sampling error. That is concrete cost/benefit evidence for excluding GEPA from the MVP and first fixing the experiment.

### Exact CPU Gate 0 contract

The locked comparison uses disjoint development and held-out phases/seeds, byte-identical developed initial states across arms, a radial action bound, separate TKE and effort accounting, opposite-phase materiality, independent seed-block wins, exact observation/action marginal checks, numerical gates, and temporal/spatial convergence. A failure in controllability, observability, causal ablation, effort, numerics, or convergence is a valid terminal result.

The runner now persists durable failure evidence: failed development searches record candidate, case, numerical-gate, partial-progress, and exception diagnostics without producing a controller lock; the explicit `convergence` stage requires and strictly loads an existing immutable primary report; repeated stages do not rerun completed evidence; and every refinement artifact binds to the protocol, lock, primary digest, effective grid, and effective `dt`. The temporal and spatial checks compare five arm means, five relative effects, exact ordering, all target/source numerical gates, and ten materiality/opposite-pair/effort decisions. These safeguards preserve the frozen v1 failure and produced the terminal, round-trip-validated v2 failure above.

### Earlier model portfolio

These configured services belong to the earlier proposal/judge/GEPA design. They do not define the current direct paired-critic screen and are not authorization to invoke it.

| Role | Configured model services |
|---|---|
| Student proposal model | `system.ai.kimi-k3` |
| Primary judge | `system.ai.claude-opus-5` |
| Audit judges | `system.ai.gpt-5-6-sol`, `system.ai.deepseek-v4-pro-0813`, `system.ai.glm-5-2` |
| Reflection models | `system.ai.gpt-5-6-sol`, `system.ai.kimi-k3`, `system.ai.claude-opus-5` |
| Small utility tasks | `system.ai.deepseek-v4-flash-0731` |

Model access uses Databricks' OpenAI-compatible MLflow AI Gateway surface where required. Unity AI Gateway remains an implementation detail rather than the focus of the demo.

### Databricks App

- Built a professional TypeScript/React AppKit replacement for the legacy Streamlit surface.
- The local containment patch is results-only: its server has no job plugin, job trigger route, or launch control, and its shared job-trigger contracts were removed.
- The contained HydroGym evidence surface has:
  - an animated, genuine uncontrolled Kolmogorov vorticity reference trajectory;
  - explicit labeling that the animation is reference physics, not PPO evidence;
  - the Re=100 v2 primary causal pass and terminal temporal/spatial convergence failure shown together, with training still locked;
  - a read-only `critic_quality` review preview filtered to measured evidence with locked fold, bundle/group, arm, and digest tags;
  - separate training-diagnostic and held-out fields;
  - a baseline-versus-approved-candidate chart populated only by dedicated `heldout/*` metrics after physics passes, evidence digests exist, scientific contexts match, frozen PPO fingerprints match, and the candidate carries compiled-reward plus human-approval digests;
  - loading, empty, error, incomplete-provenance, and stale-API-snapshot states;
  - no causal “After MemAlign + GEPA” label.

MLflow trace search exposes request/response previews, not guaranteed full payloads. The contained server therefore returns `REVIEW_WRITE_BLOCKED` for every feedback POST, and the UI disables submission until full native trace retrieval plus RunBundle/evidence-digest verification exists. This intentionally leaves the current expert-label count at zero rather than collecting low-integrity MemAlign targets.

The existing service is still `ACTIVE`, but it is the obsolete deployment and must not be used to launch work. The contained AppKit replacement has not been deployed in this continuation. Deployment requires an explicit review/consent step. The root bundle also includes legacy jobs, so a future rollout must first demonstrate a scoped app-only plan or separate the contained app into its own deployable target; a broad root `apps deploy` must not be assumed safe. Until a contained rollout completes, the live URL does not inherit the local evidence guarantees above.

## Validation and evidence state

Historical app/deployment checks remain useful infrastructure evidence, but they do not make the dirty worktree scientifically valid. Local Python and lint results below validate contracts and plumbing only; the failed Gate 0 remains failed.

| Validation | Result |
|---|---|
| Historical focused Python suite | 91 passed |
| AppKit/Vitest suite | **17 passed** |
| TypeScript checks | Passed |
| ESLint | Passed |
| AppKit AST lint | Passed |
| Prettier check | Passed; generated `appkit.plugins.json` is ignored because AppKit rewrites it |
| Production frontend/server build | Passed |
| Root Databricks bundle validation | Passed |
| Databricks Apps validation | Passed |
| Deployed app status | `ACTIVE`, legacy deployment; contained AppKit patch is not live |
| Authenticated browser render check | Passed |
| Scientific Gate 0 v1 | Durable `c6c1…` development failure records spectral-tail gate failures; exact diagnostic probe measured `0.082028 > 0.05` at `48×48` |
| Scientific Gate 0 v2 | Primary passed all 20 gates; final failed temporal/spatial arm convergence, effect convergence, and ordering; final digest `e8a19f…` |
| Fresh-seed ensemble diagnostic | All causal, numerical, and point-convergence checks passed; both effect-equivalence CIs failed; `supports_designing_full_gate=false`; result digest `e45eb7…` |
| Ten-seed ensemble replication | Protocol-only freeze verified; 120 trajectories expected; zero condition/result artifacts and zero CFD trajectories executed |
| Control-curl/task-design implementation | Repaired and contract-tested; does not override Gate 0 |
| Direct GPT/Claude transport P0 | Passed one synthetic bundle; remote run `b9908e32d1bb4cb4a633f10530f13bf5` |
| Paired SDK transport P0 | Rejected for MVP: Codex passed, Claude failed closed |
| Native dataset lineage | Local SQLite round-trip passed; publication validates target experiment, successful trace, canonical provenance, RunBundle, root span, and outputs |
| Current `test/codex_hydrogym` suite | **247 passed** locally on August 25, 2026 |
| Ruff | Passed on `codex_hydrogym`, its tests, and `hydrogym/jax` |
| Git whitespace check | Passed |
| Bound app jobs | Zero runs on each of the four current jobs |
| H100 PPO execution | No user code executed; two historical attempts failed during setup |

The scoped `test/codex_hydrogym` suite is the relevant project validation boundary. Repository-wide pytest collection also encounters optional Firedrake dependencies and vendored legacy Python-2 tests; those collection failures are outside this demo package and are not counted as project passes.

## Issues encountered and resolutions

### Databricks npm proxy and Playwright

Several deployments failed because the Databricks npm proxy returned `404 Not Found` for `playwright-core` versions 1.62.1, 1.58.2, and 1.58.1 inside the Apps build environment.

Resolution:

- pinned Playwright to a known test version;
- made it an optional, test-only dependency so production installation does not fail when the proxy omits it;
- separated the Playwright e2e TypeScript project from the production client compile;
- retained local smoke-test type checking while removing Playwright from the deployed runtime dependency boundary.

The subsequent deployment installed dependencies, built both server and client, and started successfully.

### Validation-path mismatch

Running `databricks apps validate` from the repository root failed because the root is a bundle and does not directly contain the AppKit `package.json`. Validation was moved to the nested AppKit project, while deployment correctly remained at the repository root to avoid duplicate-app ownership conflicts.

### Python test launcher

The first `uv run pytest` invocation did not place the repository packages on the import path. The suite was rerun through the repository virtual environment with `PYTHONPATH=.`. This exposed one stale assertion for the newly attached PPO job ID; the assertion was corrected, a single-experiment regression test was added, and the full suite passed.

### P0 trace destination mismatch

The P0 calls traced successfully to a local SQLite MLflow store and those traces were serialized into the durable Databricks run. They were not ingested as native remote experiment traces. A read-only `mlflow.search_traces` against experiment `103455306564903` returned zero records, and `mlflow.get_trace` could not resolve the manifest IDs remotely. The result remains valid transport evidence because the manifest and serialized artifacts are present, but it is not a valid source for a remote TRACE-derived labeling dataset. Dataset publication now verifies source existence against the active tracking store so this mismatch fails before labeling.

### Misrouted AI Runtime attempt

An earlier workload targeted the wrong MLflow experiment. That run was canceled, the accidental experiment was moved to Trash, and the reusable AI Runtime job was corrected to use `experiment_name: codex_hydrogym` under `/Workspace/Shared`, resolving to `/Shared/codex_hydrogym`.

### Historical H100 launch failure

Experiment `103455306564903` contains two `FAILED` MLflow runs associated with deleted job `278222053449531` and job run `366806901874578`. Both failed before project user code because the generated `command.sh` attempted to `cd /databricks/code_source/._air`, which was not a directory. Their traces contain only system metrics, including 0% GPU utilization; they contain no PPO, fluid, checkpoint, or physics-gate metrics. This is packaging/setup evidence, not an RL baseline and not evidence of H100 capacity pressure.

## Why no reinforcement-learning or alignment results exist yet

This is an evidence gap, not a visualization bug.

1. **The scientific task fails Gate 0 twice.** Re=200 v1 fails the `48×48` spectral-tail criterion. Re=100 v2 passes the primary causal comparison but fails both locked temporal and spatial convergence contracts. Neither authorizes PPO.
2. **No H100 user code has run.** The only two MLflow attempts failed in setup at `/databricks/code_source/._air`; GPU utilization was 0%, and no PPO or fluid metrics exist.
3. **The four currently bound jobs have never run.** Their presence and app permissions prove deployment wiring only.
4. **Transport is not quality.** GPT and Claude direct critics both passed one synthetic contract, but no measured held-out RunBundle or human quality label has been evaluated.
5. **No expert `critic_quality` labels exist.** MemAlign therefore has neither an attributable training target nor a locked held-out critic-quality evaluation set.
6. **The Codex revision lane is wiring only.** It has not consumed a measured bundle through the registered prompt, and no blinded human comparison shows that its revised reward reasoning is better. Claude and GEPA remain outside the first screen.
7. **The existing PPO job targets a different observation problem.** It does not randomize forcing phase per reset, and its training/serving path assumes the legacy speed grid rather than Gate 0's signed observation.
8. **The new causal loop has not executed.** RewardSpec compilation, prompt lineage, AIR manifest enforcement, and frozen-training parity are tested locally, but no human-approved compiled manifest or held-out RL result exists.
9. **No benefit claim is allowed yet.** Agent-feedback quality and fluid-control quality are separate hypotheses, each requiring its own held-out evidence.

## Truth boundary for the demo

The animated field is a real uncontrolled HydroGym JAX solver reference trajectory. The active legacy app, contained local AppKit replacement, tests, deployed jobs, direct transport P0, SDK follow-up, registered revision prompt, and measured-local constant-action diagnostic are foundation or diagnostic evidence. None shows that a learned controller improved the fluid, that coding-agent reward review caused an improvement, or that MemAlign improved feedback.

There are two independent claim boundaries:

- **Reviewer-alignment claim:** one exact Codex draft must feed base-reviewer and MemAlign-reviewer advice, then the same registered prompt and Codex model/adapter must produce both revisions with native remote trace lineage. Experts must label the composite 1–5 `critic_quality` target, and the MemAlign arm must improve held-out human judgment against the base reviewer and cheap deterministic/hand-written controls. MemAlign may improve reward-review feedback. It may not be described as optimizing TKE or control.
- **Fluid-control claim:** the CPU Gate 0 must pass first. A later candidate and baseline must then use identical held-out phases, seeds, developed states, horizons, numerical gates, and effort accounting. Only measured TKE improvement beyond the locked observation-free frontier with proportionate effort supports this claim.

The demo may now say that Databricks AI Gateway can host two schema-valid critic transports, MLflow stores the P0 manifest, a registered-prompt Codex revision plus deterministic reward compiler is locally contract-tested, and signed feedback passed the Re=100 primary causal comparison before final convergence failed. It cannot say that Gate 0 passed, that the remote reviewer loop ran, that MemAlign improves the reviewer, that RL improved the fluid, or that the system “improves on its own.” A human must supply the critic-quality target and approve any controller or reward change. Claude and GEPA remain optional later benchmarks, not parts of either initial claim.

## Post-v2 stop plan

1. Preserve the immutable v1 and v2 protocols and every evidence artifact. Do not reinterpret the v2 primary pass as final success or overwrite either failed run.
2. Stop before PPO, H100, measured reviewer enrollment, MemAlign, GEPA, or deployment. The v2 runner has reached the preregistered terminal condition.
3. Prefer ending this demo lane as a successful falsification rather than introducing a third protocol to rescue the original story. The current evidence says signed feedback is promising but the benchmark is not quantitatively converged under its own frozen contract.
4. A fixed exploratory ten-seed replication-sizing protocol is now implemented and frozen to investigate seed-level uncertainty. Keep it explicitly nonconfirmatory, do not execute it without explicit CPU confirmation, and do not relax v2 tolerances, remove failed arms, pool the prior four seeds, replace seeds, stop early, or extend the sample after observing results.
5. Only an independently motivated, newly preregistered task that passes its complete CPU gate could reopen the downstream path: repair PPO reset/observation/model-signature contracts, build a separate digest-bound held-out evaluator, then create measured RunBundles.
6. Keep the App evidence-only. If the contained local AppKit surface is later deployed with explicit consent, it should show the v2 primary result and convergence failure together; it must not render the primary pass as RL or fluid-improvement evidence.
7. Retain Codex plus human `critic_quality` review as the simplest eventual reviewer experiment. Run MemAlign only after sufficient attributable, grouped HUMAN labels exist. Claude and GEPA remain optional later benchmarks, not recovery mechanisms for a failed physics gate.

## Current handoff

The highest-confidence eventual architecture remains one Codex harness, a registered revision prompt, human `critic_quality` labels, base-versus-MemAlign reviewer advice, deterministic human-approved reward compilation, and a coefficient-grid control—but only after valid fluid evidence exists. That architecture is wired but unproven, and GEPA has no current role. Re=100 Gate 0 v2 failed final convergence despite a clean causal primary pass, and the four-seed diagnostic failed both equivalence intervals. The only prepared continuation is the separately frozen, unexecuted ten-seed replication-sizing study above. Its next action is an explicit CPU-spend decision, not PPO or an automatic Gate 0 v3; until then, the honest result remains falsification and the downstream lane stays blocked.
