# codex_hydrogym continuation handoff

**Prepared:** August 25, 2026  
**Repository:** `/Users/austin.choi/PycharmProjects2/hydrogym`  
**Primary status document:** `codex_hydrogym/STATUS_REPORT.md`  
**Original Codex session referenced by the user:** `01a02f5d-8563-7db0-b19c-88edc7aca608`

## Read this first

This project is promising but not yet RL-ready. The strongest honest conclusion is:

- a hand-designed signed forced-mode feedback controller has a large and highly consistent causal effect at Re=100;
- the latest development-only ensemble passed every numerical, causal, window-stability, and point-convergence check;
- it still failed both uncertainty-aware effect-equivalence checks, narrowly;
- a separate ten-new-seed replication protocol is now frozen but has not executed any CFD;
- therefore scientific Gate 0 remains failed, and no PPO, coding-agent reward comparison, MemAlign training, GEPA, H100 job, model promotion, or deployment is authorized by the evidence.

Do not convert the latest near miss into a pass. The current result is useful because it narrows the problem from gross numerical/point nonconvergence to seed-level uncertainty.

`STATUS_REPORT.md` is the detailed source of record. This file is the operational handoff for continuing safely.

## Non-negotiable scientific boundaries

1. HydroGym computes executable rewards deterministically. A coding agent may propose or revise a bounded RewardSpec; it must never execute reward code inside the environment.
2. MemAlign can improve agreement of a `critic_quality` reviewer with expert judgment. It cannot improve or certify fluid dynamics directly.
3. No PPO or H100 work occurs until an independently held-out, preregistered CPU Gate 0 passes.
4. Never relax thresholds, drop difficult arms, append cases to a completed study, or reinterpret a failed screen after observing its result.
5. Preserve every frozen artifact and its source implementation. New scientific work gets a new study ID, source file, protocol fingerprint, and evidence directory.
6. A passing development diagnostic only permits designing a separately frozen held-out gate. It is not itself a Gate 0 pass.
7. Failure is an acceptable terminal result. Do not force a success for the demo.

## Current evidence chronology

### Gate 0 v1: numerical failure

- Protocol fingerprint: `ab83f36f4ed9991320ac6e191bb6330d4c7fdc502430a4b65bf4c5fbbe598fd5`
- Executed failure evidence: `codex_hydrogym/evidence/gate0/ab83f36f4ed9-c6c1c6002c25/development_search_failure.json`
- Failure digest: `c0be6dd593c948fd57437996f9f81274ce11c7e1736338d3c00e3c7346c80140`
- Re=200 at `48×48` reached a retained spectral-tail fraction of `0.082028`, above the frozen `0.05` limit.
- The similarly named `ab83f36f4ed9-c757978ca1e5` directory contains only a pre-execution protocol and must not be cited as the executed failure.

### Gate 0 v2: primary causal pass, final convergence failure

- Protocol fingerprint: `2729e365a5712b824d4d1a2257ade19519aa454509a221790ddcabf2021b32a9`
- Implementation digest: `5cc598c6b6e6168ec78d80360326d8d595ada81f4c9790b4d1c86b67f28350c4`
- Evidence directory: `codex_hydrogym/evidence/gate0/2729e365a571-5cc598c6b6e6`
- Primary artifact digest: `9ac1987e99bdaf7936a4c45047bf48d3e0df522bf95e22df1bf90b7edcbbc676`
- Convergence attestation digest: `a7903f7fd7798118d6f27ace45cbaff043665d1aeee4f0a8fdd8ef6daa440d1d`
- Final failed-report digest: `e8a19fa835a991f233ed7087c31a7c947c6a61a9a3c04ceb935db2870f8dd463`

The primary comparison passed all 20 gates:

| Arm | Mean TKE | Mean RMS L2 effort |
|---|---:|---:|
| Privileged oracle | `0.729081` | `0.500000` |
| Signed feedback | `1.135629` | `0.334375` |
| Zero | `1.909851` | `0.000000` |
| Locked fixed | `1.912044` | `0.250000` |
| Observation deranged | `1.958062` | `0.334375` |

The final convergence stage failed:

| Refinement | Max arm change | Limit | Max effect drift | Limit |
|---|---:|---:|---:|---:|
| Temporal | `8.0715%` | `2%` | `0.053650` | `0.02` |
| Spatial | `5.3793%` | `5%` | `0.042492` | `0.03` |

This result remains failed even though the feedback arm itself was comparatively stable. The zero/reference arm was the largest source of point sensitivity.

### Fresh-seed ensemble diagnostic: strong signal, negative screen

Runner: `codex_hydrogym/gate0/ensemble_diagnostic.py`  
Tests: `test/codex_hydrogym/test_ensemble_diagnostic.py`  
Evidence: `codex_hydrogym/evidence/ensemble_diagnostic/19927dd9f42c-0df64047e2c1`

- Study fingerprint: `19927dd9f42cdcda5a7faf938a1a9da7814e4bb3031a1f15b08670ece6dd6caf`
- Implementation digest: `0df64047e2c1372b79fb92420c2c99f75213f3386c1fc06767cd31f203de674b`
- Protocol artifact digest: `da12d0149689a632acf2dd76b02d7dfe9954ac3db0d50f3070915730ca60abf5`
- Base condition digest: `2d3e9b41c329a5a0e9692a68c17319b01bf8cec97924f6123a751a045ea509f3`
- Temporal condition digest: `e819c1b2a65450253ab75476365dda28092fbd77e933639efa86ad6f34768860`
- Spatial condition digest: `86c508e165271419d7b63a86ecbb83e53fc4926acafc6a143b229a290d759439`
- Result digest: `e45eb7f6b19b52d6580462ef22e0efcc87a6cd435916f88694ef25e375777d9b`
- Frozen decision: `supports_designing_full_gate=false`

Frozen design:

- Re=100, float64
- development seeds `401, 503, 607, 709`
- development phases `0.0625, 0.5625`, an opposite-phase pair
- reserved, unopened seeds `907, 1009`
- reserved, unopened phases `0.1875, 0.6875`
- uncontrolled burn-in `100` intervals
- controller warmup `50` intervals
- two consecutive scoring windows of `100` intervals each
- zero and gain-2 signed-feedback arms only
- radial action bound `0.5`
- base `64×64, dt=0.002`
- temporal `64×64, dt=0.001`, old margins `2%` arm and `2 pp` effect
- spatial `96×96, dt=0.002`, old margins `5%` arm and `3 pp` effect
- inference clustered by the four independent seeds

Observed condition metrics:

| Condition | Zero TKE | Feedback TKE | Aggregate reduction | Seed-cluster effect 95% CI | Minimum block reduction |
|---|---:|---:|---:|---:|---:|
| Base | `1.869819` | `1.108867` | `40.6965%` | `[38.8662%, 42.2993%]` | `35.3819%` |
| Temporal | `1.871635` | `1.102617` | `41.0881%` | `[38.9286%, 43.0175%]` | `33.4377%` |
| Spatial | `1.939336` | `1.112311` | `42.6448%` | `[40.0240%, 45.1252%]` | `38.0000%` |

Signed feedback beat zero in all 48 seed × phase × window blocks. Every numerical gate passed. Both window means were material in every condition, and all seed-cluster 95% intervals were far above the `5%` effect floor.

Refinement metrics:

| Refinement | Max arm difference | Arm limit | Aggregate effect difference | Effect limit | Paired-seed effect-difference 90% CI | Point checks | Equivalence CI |
|---|---:|---:|---:|---:|---:|---|---|
| Temporal | `0.5637%` | `2%` | `0.3915 pp` | `2 pp` | `[-1.7387, +2.5192] pp` | Pass | **Fail** |
| Spatial | `3.7179%` | `5%` | `1.9483 pp` | `3 pp` | `[+0.3957, +3.5879] pp` | Pass | **Fail** |

Exactly two screening predicates were false:

- `temporal_effect_equivalence_ci_supported`
- `spatial_effect_equivalence_ci_supported`

The temporal upper interval missed by `0.5192 pp`; the spatial upper interval missed by `0.5879 pp`. This is a real negative result, not a process error.

## Evidence integrity already verified

The existing evidence was round-tripped without rerunning CFD, and a separate read-only audit verified:

- all five diagnostic artifact digests;
- all seven frozen implementation-file hashes;
- all 48 condition traces;
- all 48 paired seed/phase/window blocks;
- paired initial and control-start state identities;
- window continuity and recomputed means;
- exact reproduction of the stored analysis;
- exact links to the v2 protocol and failed final report.

The current runner can revalidate the completed directory because existing condition artifacts prevent simulation:

```bash
PYTHONPATH=. uv run python -m codex_hydrogym.gate0.ensemble_diagnostic \
  --stage run \
  --output-dir codex_hydrogym/evidence/ensemble_diagnostic/19927dd9f42c-0df64047e2c1
```

Do not edit `ensemble_diagnostic.py` or any artifact in that evidence directory. Its source is implementation-hash-bound. Implement future studies in a new sibling module.

## Frozen replication-sizing diagnostic, not yet executed

The next defensible study is now implemented and frozen separately from the completed four-seed diagnostic. It has not executed any CFD. Obtain explicit confirmation before spending the CPU budget on the run.

Runner: `codex_hydrogym/gate0/ensemble_replication.py`  
Tests: `test/codex_hydrogym/test_ensemble_replication.py`  
Evidence: `codex_hydrogym/evidence/ensemble_replication/269507101a52-a5ab894e5ff4`

- Study fingerprint: `269507101a5206fccab3c90504f7a46009f28381070a0d97875a06429fb19b62`
- Implementation digest: `a5ab894e5ff4d3b669da274771f247e58f06aab992873fc9fe76dfdcf8622d8c`
- Protocol artifact digest: `3914aedc99979693bf693772a56eef83c3c242c6cd72dc7fda8c07583d781c87`
- Status: `frozen_before_execution`
- Condition artifacts: none
- CFD trajectories executed: zero

Frozen design:

1. Use the ten SHA-256-derived development seeds `1100085772, 619716833, 1680869979, 270788329, 1326527252, 625393611, 901546380, 1422036434, 373522063, 1374108181`.
2. Do not reuse the prior four seeds as confirmatory observations and do not append results to the completed study.
3. Keep seeds `907, 1009` and phases `0.1875, 0.6875` sealed.
4. Preserve the same Re, precision, development phase pair, burn-in, warmup, two windows, arms, controller, grids, time steps, numerical gates, materiality floor, and convergence/equivalence margins.
5. Analyze the 10 new seeds as one fixed sample. No interim looks, optional stopping, seed replacement, or extension after seeing results.
6. Persist an immutable protocol before any CFD execution and use resumable, content-addressed artifacts per condition.
7. The run contains `3 conditions × 10 seeds × 2 phases × 2 arms = 120` trajectories, about 2.5 times the completed diagnostic.

Why 10 is a reasonable planning target, not evidence:

- observed temporal paired-difference mean `0.003902746`, standard error `0.009046426` at `n=4`, implied seed SD approximately `0.018092852`;
- observed spatial paired-difference mean `0.019918142`, standard error `0.006782164` at `n=4`, implied seed SD approximately `0.013564328`;
- a plug-in calculation suggests roughly seven seeds could suffice if the observed means and variances remained unchanged;
- ten fresh seeds provide some buffer, especially for the spatial `3 pp` margin, but do not guarantee a pass.

The frozen protocol retains the current screening logic:

- all numerical gates pass;
- feedback beats zero in every seed/phase/window block;
- every consecutive-window mean effect is at least `5%`;
- every seed-cluster effect 95% CI has lower bound at least `5%`;
- temporal arm and aggregate-effect point differences are within `2%` and `2 pp`;
- spatial arm and aggregate-effect point differences are within `5%` and `3 pp`;
- the paired-seed 90% temporal effect-difference CI lies wholly inside `[-2, +2] pp`;
- the paired-seed 90% spatial effect-difference CI lies wholly inside `[-3, +3] pp`.

Implementation state:

- the new study/schema ID and claim boundary are distinct from the completed diagnostic;
- the runner imports the hash-bound diagnostic execution and analysis contract without modifying it;
- the manifest binds the new source, prior runner, Gate 0 runner/protocol, and four physics sources;
- `run` fails unless the exact protocol was frozen first;
- completed condition artifacts are immutable and resumable, and the loader independently checks hashes, exact cases/arms, numerical-gate schema, window continuity and means, and paired initial/control-start states;
- seven focused tests and all 247 scoped Python tests pass;
- the protocol and all eight implementation hashes were independently revalidated after freezing.

After explicit confirmation, execute only this command:

```bash
PYTHONPATH=. .venv/bin/python -m codex_hydrogym.gate0.ensemble_replication \
  --stage run \
  --output-dir codex_hydrogym/evidence/ensemble_replication/269507101a52-a5ab894e5ff4
```

### Decision after the replication

If the replication screen passes:

- it supports designing, not claiming, a full Gate 0 v3;
- preregister an adequately sized held-out seed set before opening any reserved cases;
- restore the full zero/fixed/oracle/signed-feedback/deranged arm set;
- restore effort matching, global marginal checks, opposite-phase decisions, all numerical gates, and digest-bound temporal/spatial convergence;
- execute the full gate once.

If the replication screen fails:

- stop treating the current formulation as RL-ready;
- do not add more seeds or change margins post hoc;
- either record the current formulation as a negative result or define a genuinely new benchmark protocol, for example with a prospectively justified horizon or different task regime;
- restart development/held-out separation for that new problem.

## Work allowed only after a full Gate 0 pass

The existing PPO path does not implement the repaired Gate 0 task contract. Before any bounded training run, repair and test:

1. phase randomization inside vectorized episode resets instead of one fixed forcing phase;
2. the signed two-value forced-mode observation instead of the legacy `8×8` speed-grid observation;
3. policy packaging and serving signatures that currently assume `obs_size**2` inputs;
4. evaluation-context and checkpoint binding for the repaired observation/action contract;
5. zero, fixed-controller, and small reward-coefficient-grid baselines before PPO;
6. one bounded PPO trial with unchanged optimizer/compute settings across reward arms;
7. separate held-out evaluation with immutable evidence digests.

Only measured RunBundles from a valid task should feed the coding-agent reviewer experiment.

## Coding-agent and MemAlign state

- Codex is the intended first coding-agent harness; Claude and GEPA are deferred.
- Direct GPT and Claude transport passed one synthetic bundle only in remote MLflow run `b9908e32d1bb4cb4a633f10530f13bf5`.
- That run proves schema transport, not critic quality or fluid improvement.
- Its traces were created in a local MLflow store and serialized remotely; the target remote experiment contains zero retrievable native traces from that run.
- There are zero eligible adjudicated `critic_quality` labels.
- The current `align` CLI/job still targets legacy `fluid_reward_plausibility`, not the intended grouped `critic_quality` workflow.
- Alignment provenance, grouped train/held-out isolation, prompt-lineage rereads, and HUMAN/calibration artifact verification need repair before a measured reviewer experiment.
- Do not run MemAlign merely to create activity. It requires measured native traces, locked groups, and eligible human labels.

The intended later sequence remains:

`passing CPU Gate 0 → repaired PPO/evaluation contract → measured RunBundles → one Codex RewardSpec draft → base versus MemAlign reviewer advice → same-Codex paired revisions → human critic_quality labels and held-out reviewer evaluation → human approval → deterministic reward compilation → one bounded RL trial`

## App and Databricks state

- Databricks profile explicitly used for prior read-only inspection: `dais-demo`.
- Never auto-select a profile; pass `--profile dais-demo` only when the user has kept that choice in scope.
- No Databricks mutation occurred in the latest continuation.
- The live app remains the obsolete deployment and must not be treated as reflecting the local containment/evidence work.
- The local AppKit copy now presents the v2 failure and the negative ensemble screen together in `codex_hydrogym/appkit/codex-hydrogym/client/src/pages/DemoPage.tsx`.
- The local contained app has no launch controls and remains undeployed.
- Do not broadly deploy the root bundle: it includes legacy jobs. A future deployment needs explicit user consent and a scoped app-only plan or separately isolated target.
- Do not start the bound feedback, MemAlign, GEPA, or H100 jobs.

## Validation state at handoff

The following passed locally on August 25, 2026:

```text
247 scoped Python tests
17 AppKit/Vitest tests
Ruff
TypeScript typecheck
ESLint
AppKit AST lint
Prettier
production server/client build
git diff --check
```

Commands:

```bash
PYTHONPATH=. .venv/bin/python -m pytest -q test/codex_hydrogym
.venv/bin/ruff check codex_hydrogym test/codex_hydrogym hydrogym/jax

cd codex_hydrogym/appkit/codex-hydrogym
npm test
npm run typecheck
npm run lint
npm run lint:ast-grep
npm run format -- --ignore-unknown
npm run build

cd ../../..
git diff --check
```

The production build emits only non-fatal warnings about stale Browserslist data and a large client chunk. Do not update dependencies merely to silence those warnings without a separate reason.

## Worktree caution

The repository is intentionally dirty and much of `codex_hydrogym/` is currently untracked from Git's perspective. Existing modifications belong to the user and prior work. At the last audit, `git status --short` included:

```text
 M .gitignore
 M hydrogym/jax/envs/kolmogorov.py
 M hydrogym/jax/solvers/base.py
 M hydrogym/jax/utils/utils.py
 M pyproject.toml
?? .isaac/
?? codex_hydrogym/
?? databricks.yml
?? hydrogym/jax/kolmogorov_contract.py
?? resources/
?? test/codex_hydrogym/
?? uv.lock
```

Do not reset, clean, overwrite, or commit unrelated work. Inspect before editing and use narrow patches.

## Immediate next-agent checklist

1. Read `codex_hydrogym/STATUS_REPORT.md` and this handoff completely.
2. Inspect `git status --short`; preserve all existing work.
3. Obtain explicit user confirmation before spending the CPU budget on the frozen 120-trajectory replication.
4. If authorized, execute the exact frozen command above once and resumably; do not change source, seeds, horizons, margins, or the output directory.
5. Validate every condition/result artifact, source hash, paired block, and recomputed analysis independently.
6. Update `STATUS_REPORT.md`, this handoff, and the undeployed local AppKit copy with the exact result.
7. Stop before PPO unless a separately frozen full Gate 0 is later executed and passes.
