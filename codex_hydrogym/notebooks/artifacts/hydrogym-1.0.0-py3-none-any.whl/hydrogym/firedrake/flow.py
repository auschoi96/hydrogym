from functools import partial
from typing import Callable, Iterable, NamedTuple

import firedrake as fd
import numpy as np
import pyadjoint
import ufl
from firedrake import dx, logging
from mpi4py import MPI
from numpy.typing import ArrayLike
from ufl import curl, div, dot, inner, nabla_grad, sqrt, sym

from ..core import ActuatorBase, PDEBase
from .actuator import DampedActuator
from .utils.linalg import DirectOperator, InverseOperator

# Use interpolate from firedrake directly (works in both old and new versions)
interpolate = fd.interpolate


class ScaledDirichletBC(fd.DirichletBC):
    def __init__(self, V, g, sub_domain, method=None):
        self.unscaled_function_arg = g
        self._scale = fd.Constant(1.0)

        # Handle Firedrake API changes across versions
        # Newer versions: DirichletBC(V, g, sub_domain)  - no method parameter
        # Older versions: DirichletBC(V, g, sub_domain, method=None)
        try:
            # Try newer API first (no method parameter)
            super().__init__(V, self._scale * g, sub_domain)
        except TypeError:
            # Fall back to older API with method parameter
            try:
                super().__init__(V, self._scale * g, sub_domain, method=method)
            except TypeError:
                # Last resort: positional method argument
                super().__init__(V, self._scale * g, sub_domain, method)

    def set_scale(self, c):
        self._scale.assign(c)


class ObservationFunction(NamedTuple):
    func: Callable
    num_outputs: int

    def __call__(self, q: fd.Function) -> np.ndarray:
        return self.func(q)


class FlowConfig(PDEBase):
    DEFAULT_REYNOLDS = 1
    DEFAULT_VELOCITY_ORDER = 2  # Taylor-Hood elements
    DEFAULT_STABILIZATION = "none"
    MESH_DIR = ""

    FUNCTIONS = ("q",)  # tuple of functions necessary for the flow

    def __init__(self, velocity_order=None, **config):
        self.Re = fd.Constant(ufl.real(config.get("Re", self.DEFAULT_REYNOLDS)))

        if velocity_order is None:
            velocity_order = self.DEFAULT_VELOCITY_ORDER
        self.velocity_order = velocity_order

        probes = config.pop("probes", None)
        if probes is None:
            probes = []

        # Store probes for later validation (after mesh is loaded)
        self._probes_to_validate = probes if len(probes) > 0 else None
        self._validate_probes_on_init = config.pop("validate_probes", True)

        probe_obs_types = {
            "velocity_probes": ObservationFunction(partial(self.velocity_probe, probes), num_outputs=2 * len(probes)),
            "pressure_probes": ObservationFunction(partial(self.pressure_probe, probes), num_outputs=len(probes)),
            "vorticity_probes": ObservationFunction(partial(self.vorticity_probe, probes), num_outputs=len(probes)),
        }

        self.obs_fun = self.configure_observations(
            obs_type=config.pop("observation_type", None),
            probe_obs_types=probe_obs_types,
        )

        # Process restart parameter - resolve environment names to checkpoint paths
        # or auto-infer from flow configuration
        mesh = config.get("mesh", self.MESH_DIR)
        cache_dir = config.pop("cache_dir", None)  # Custom cache directory (optional)
        local_dir = config.pop("local_dir", None)  # Local fallback directory (optional)
        use_HF_data_manager = config.pop("use_HF_data_manager", True)  # Control HF data manager usage (default: True)

        # Extract numeric Reynolds number from Firedrake Constant
        Re_value = int(float(self.Re))

        resolved_restart = self._resolve_checkpoint(
            restart=config.get("restart"),
            Re=Re_value,
            mesh=mesh,
            cache_dir=cache_dir,
            local_dir=local_dir,
            use_HF_data_manager=use_HF_data_manager,
        )

        # Store resolved checkpoint path for verification/debugging
        self.checkpoint_path = resolved_restart

        config["restart"] = resolved_restart

        super().__init__(**config)

    def _resolve_checkpoint(self, restart, Re, mesh, cache_dir=None, local_dir=None, use_HF_data_manager=True):
        """Resolve checkpoint parameter to actual file path(s).

            Handles four cases:
            1. None - auto-infer environment name from config and try to download
            2. Explicit path (str starting with / or ./) - use directly
            3. Environment name (str like 'Cylinder_2D_Re100_medium_FD') - download from HF Hub
            4. List of paths/names - process each one

        Args:
            restart: None, str (path or env name), or list of str
            Re: Reynolds number (for auto-inference)
            mesh: Mesh resolution (for auto-inference)
            cache_dir: Custom cache directory (optional)
            local_dir: Local fallback directory (optional)
            use_HF_data_manager: Whether to use HF data manager for checkpoint resolution (default: True)

        Returns:
            None, str (resolved path), or list of str (resolved paths)
        """
        if restart is None:
            # Auto-infer environment name from flow configuration
            flow_name = self.__class__.__name__
            env_name = f"{flow_name}_2D_Re{Re}_{mesh}_FD"

            logging.log(logging.INFO, f"No checkpoint specified, attempting to auto-load: {env_name}")

            resolved = self._resolve_single_checkpoint(
                env_name, cache_dir, local_dir, use_HF_data_manager=use_HF_data_manager, silent=True
            )
            if resolved is None:
                logging.log(logging.INFO, f"No checkpoint found for {env_name}, starting from zeros")
            return resolved

        if isinstance(restart, str):
            return self._resolve_single_checkpoint(
                restart, cache_dir, local_dir, use_HF_data_manager=use_HF_data_manager
            )

        elif isinstance(restart, (list, tuple)):
            # Process multiple checkpoints
            resolved = []
            for ckpt in restart:
                resolved_ckpt = self._resolve_single_checkpoint(
                    ckpt, cache_dir, local_dir, use_HF_data_manager=use_HF_data_manager
                )
                if resolved_ckpt is not None:
                    resolved.append(resolved_ckpt)
            return resolved if resolved else None

        else:
            logging.log(logging.WARN, f"Invalid restart type: {type(restart)}, ignoring")
            return None

    def _resolve_single_checkpoint(
        self, checkpoint, cache_dir=None, local_dir=None, use_HF_data_manager=True, silent=False
    ):
        """Resolve a single checkpoint path or environment name.

        Args:
            checkpoint: str (path or environment name)
            cache_dir: Custom cache directory (optional)
            local_dir: Local fallback directory (optional)
            use_HF_data_manager: Whether to use HF data manager for checkpoint resolution (default: True)
            silent: If True, suppress warnings for missing checkpoints (for auto-inference)

        Returns:
            str (resolved path) or None if resolution fails
        """
        import os
        from pathlib import Path

        # Check if it's an explicit path
        if (
            checkpoint.startswith("/")
            or checkpoint.startswith("./")
            or checkpoint.startswith("../")
            or os.path.exists(checkpoint)
        ):
            # Explicit path provided - use directly
            if os.path.exists(checkpoint):
                logging.log(logging.INFO, f"Using checkpoint: {checkpoint}")
                return checkpoint
            else:
                if not silent:
                    logging.log(logging.WARN, f"Checkpoint path does not exist: {checkpoint}")
                return None

        # If HF data manager is disabled, don't try to resolve from HF Hub
        if not use_HF_data_manager:
            if not silent:
                logging.log(logging.INFO, f"HF data manager disabled, skipping checkpoint resolution for: {checkpoint}")
            return None

        # Assume it's an environment name - try to download from HF Hub
        try:
            from hydrogym.data_manager import HFDataManager

            if not silent:
                logging.log(logging.INFO, f"Resolving checkpoint from environment: {checkpoint}")

            dm = HFDataManager(
                cache_dir=cache_dir,  # Use custom cache dir if provided
                local_fallback_dir=local_dir,  # Use local directory for offline/testing
                use_clean_cache="copy",  # Use 'copy' for readable ckpts
                fallback_profile="FIREDRAKE",
            )

            # Get environment path (downloads if needed)
            env_path = dm.get_environment_path(checkpoint)

            # Find checkpoint file(s) in the environment directory
            checkpoint_files = list(Path(env_path).glob("checkpoint*.h5"))
            if not checkpoint_files:
                checkpoint_files = list(Path(env_path).glob("*.ckpt"))

            if checkpoint_files:
                resolved_path = str(checkpoint_files[0].resolve())
                logging.log(logging.INFO, f"✓ Checkpoint resolved: {resolved_path}")
                return resolved_path
            else:
                if not silent:
                    logging.log(logging.WARN, f"No checkpoint file found in environment: {checkpoint}")
                return None

        except ImportError:
            if not silent:
                logging.log(
                    logging.WARN,
                    "HuggingFace Hub not available (pip install huggingface_hub). Checkpoint resolution disabled.",
                )
            return None
        except Exception as e:
            if not silent:
                logging.log(logging.WARN, f"Could not resolve checkpoint '{checkpoint}': {e}")
            return None

    def load_mesh(self, name: str) -> ufl.Mesh:
        return fd.Mesh(f"{self.MESH_DIR}/{name}.msh", name="mesh")

    def save_checkpoint(self, filename: str, write_mesh=True, idx=None):
        with fd.CheckpointFile(filename, "w") as chk:
            if write_mesh:
                chk.save_mesh(self.mesh)  # optional
            for f_name in self.FUNCTIONS:
                chk.save_function(getattr(self, f_name), idx=idx)

            act_state = np.array([act.state for act in self.actuators])
            chk.set_attr("/", "act_state", act_state)

    def load_checkpoint(self, filename: str, idx=None, read_mesh=True):
        with fd.CheckpointFile(filename, "r") as chk:
            if read_mesh:
                self.mesh = chk.load_mesh("mesh")
                self.initialize_state()
            else:
                assert hasattr(self, "mesh")
            for f_name in self.FUNCTIONS:
                try:
                    f_load = chk.load_function(self.mesh, f_name, idx=idx)
                    f_self = getattr(self, f_name)

                    # If the checkpoint saved on a different function space,
                    # approximate the same field on the current function space
                    # by projecting the checkpoint field onto the current space
                    V_chk = f_load.function_space()
                    V_self = f_self.function_space()
                    if V_chk.ufl_element() != V_self.ufl_element():
                        f_load = fd.project(f_load, V_self)

                    f_self.assign(f_load)
                except RuntimeError:
                    logging.log(
                        logging.WARN,
                        f"Function {f_name} not found in checkpoint, defaulting to zero.",
                    )

            if chk.has_attr("/", "act_state"):
                act_state = chk.get_attr("/", "act_state")
                for i in range(self.num_inputs):
                    self.actuators[i].state = act_state[i]

        self.split_solution()  # Reset functions so self.u, self.p point to the new solution

    def configure_observations(self, obs_type=None, probe_obs_types={}) -> ObservationFunction:
        raise NotImplementedError

    def get_observations(self) -> np.ndarray:
        return self.obs_fun(self.q)

    @property
    def num_outputs(self) -> int:
        # This may be lift/drag, a stress "sensor", or a set of probe locations
        return self.obs_fun.num_outputs

    def initialize_state(self):
        # Set up UFL objects referring to the mesh
        self.n = fd.FacetNormal(self.mesh)
        self.x, self.y = fd.SpatialCoordinate(self.mesh)

        # Set up Taylor-Hood elements
        self.velocity_space = fd.VectorFunctionSpace(self.mesh, "CG", self.velocity_order)
        self.pressure_space = fd.FunctionSpace(self.mesh, "CG", 1)
        self.mixed_space = fd.MixedFunctionSpace([self.velocity_space, self.pressure_space])
        for f_name in self.FUNCTIONS:
            setattr(self, f_name, fd.Function(self.mixed_space, name=f_name))

        self.split_solution()  # Break out and rename main solution

        self._vorticity = fd.Function(self.pressure_space, name="vort")

        # Validate probe locations if configured
        if self._validate_probes_on_init and self._probes_to_validate is not None:
            try:
                self._validate_probes(self._probes_to_validate)
                logging.log(logging.INFO, f"✓ Validated {len(self._probes_to_validate)} probe location(s)")
            except ValueError as e:
                logging.log(logging.ERROR, f"Probe validation failed: {e}")
                raise

    def set_state(self, q: fd.Function):
        """Set the current state fields

        Args:
            q (fd.Function): State to be assigned
        """
        self.q.assign(q)

    def copy_state(self, deepcopy: bool = True) -> fd.Function:
        """Return a copy of the current state fields

        Returns:
            q (fd.Function): copy of the flow state
        """
        return self.q.copy(deepcopy=deepcopy)

    def create_actuator(self, tau=None) -> ActuatorBase:
        """Create a single actuator for this flow"""
        if tau is None:
            tau = self.TAU
        return DampedActuator(1 / tau)

    def reset_controls(self, function_spaces=None):
        """Reset the controls to a zero state

        Note that this is broken out from `reset` because
        the two are not necessarily called together (e.g.
        for linearization or deriving the control vector)

        TODO: Allow for different kinds of actuators
        """
        self.actuators = [self.create_actuator() for _ in range(self.num_inputs)]
        self.init_bcs(function_spaces=function_spaces)

    @property
    def nu(self):
        return fd.Constant(1 / ufl.real(self.Re))

    def split_solution(self):
        self.u, self.p = self.q.subfunctions
        self.u.rename("u")
        self.p.rename("p")

    def vorticity(self, u: fd.Function = None) -> fd.Function:
        """Compute the vorticity field `curl(u)` of the flow

        Args:
            u (fd.Function, optional):
                If given, compute the vorticity of this velocity
                field rather than the current state.

        Returns:
            fd.Function: vorticity field
        """
        if u is None:
            u = self.u
        self._vorticity.project(curl(u))
        return self._vorticity

    def function_spaces(self, mixed: bool = True):
        """Function spaces for velocity and pressure

        Args:
            mixed (bool, optional):
                If True (default), return subspaces of the mixed velocity/pressure
                space. Otherwise return the segregated velocity and pressure spaces.

        Returns:
            Tuple[fd.FunctionSpace, fd.FunctionSpace]: Velocity and pressure spaces
        """
        if mixed:
            V = self.mixed_space.sub(0)
            Q = self.mixed_space.sub(1)
        else:
            V = self.velocity_space
            Q = self.pressure_space
        return V, Q

    def collect_bcu(self) -> Iterable[fd.DirichletBC]:
        """List of velocity boundary conditions"""
        return []

    def collect_bcp(self) -> Iterable[fd.DirichletBC]:
        """List of pressure boundary conditions"""
        return []

    def collect_bcs(self) -> Iterable[fd.DirichletBC]:
        """List of all boundary conditions"""
        return self.collect_bcu() + self.collect_bcp()

    def epsilon(self, u) -> ufl.Form:
        """Symmetric gradient (strain) tensor"""
        return sym(nabla_grad(u))

    def sigma(self, u, p) -> ufl.Form:
        """Newtonian stress tensor"""
        return 2 * self.nu * self.epsilon(u) - p * fd.Identity(len(u))

    def residual(self, q, q_test=None):
        """Nonlinear residual for the incompressible Navier-Stokes equations.

        Returns a UFL form F(u, p, v, s) = 0, where (u, p) is the trial function
        and (v, s) is the test function.  This residual is also the right-hand side
        of the unsteady equations.

        A linearized form can be constructed by calling:
        ```
        F = flow.residual((uB, pB), (v, s))
        J = fd.derivative(F, qB, q_trial)
        ```
        """
        (u, p) = q
        if q_test is None:
            (v, s) = fd.TestFunctions(self.mixed_space)
        else:
            (v, s) = q_test

        sigma, epsilon = self.sigma, self.epsilon
        F = -inner(dot(u, nabla_grad(u)), v) * dx - inner(sigma(u, p), epsilon(v)) * dx + inner(div(u), s) * dx
        return F

    @pyadjoint.no_annotations
    def max_cfl(self, dt) -> float:
        """Estimate of maximum CFL number"""
        h = fd.CellSize(self.mesh)
        CFL = fd.assemble(interpolate(dt * sqrt(dot(self.u, self.u)) / h, self.pressure_space))
        # Handle both old and new Firedrake API
        try:
            max_val = CFL.vector().max()
        except AttributeError:
            max_val = CFL.dat.data_ro.max()
        return self.mesh.comm.allreduce(max_val, op=MPI.MAX)

    @property
    def body_force(self):
        return fd.Function(self.velocity_space).assign(fd.Constant((0.0, 0.0)))

    def linearize_bcs(self):
        """Sets the boundary conditions appropriately for linearized flow"""
        raise NotImplementedError

    def set_control(self, act: ArrayLike = None):
        """
        Directly sets the control state

        Note that for time-varying controls it will be better to adjust the controls
        in the timestepper, e.g. with `solver.step(iter, control=c)`.  This could be used
        to change control for a steady-state solve, for instance, and is also used
        internally to compute the control matrix
        """
        if act is not None:
            super().set_control(act)

            if hasattr(self, "bcu_actuation"):
                for i in range(self.num_inputs):
                    u = np.clip(self.actuators[i].state, -self.MAX_CONTROL, self.MAX_CONTROL)
                    self.bcu_actuation[i].set_scale(u)

    def inner_product(
        self,
        q1: fd.Function,
        q2: fd.Function,
        assemble=True,
        augmented=False,
    ):
        """Energy inner product for the Navier-Stokes equations.

        `augmented` is used to specify whether the function space is
        extended to represent complex numbers. In this case the inner
        product is the L2 norm of the real and imaginary parts.
        """
        if not augmented:
            (u, _) = fd.split(q1)
            (v, _) = fd.split(q2)
            M = inner(u, v) * dx

        else:
            (u_re, _, u_im, _) = fd.split(q1)
            (v_re, _, v_im, _) = fd.split(q2)
            M = (inner(u_re, v_re) + inner(u_im, v_im)) * dx

        if not assemble:
            return M
        return fd.assemble(M)

    def _validate_probes(self, probes: ArrayLike, mesh: fd.Mesh = None) -> None:
        """Validate that probe locations are inside the mesh.

        Args:
            probes: Array of (x, y) probe coordinates
            mesh: Mesh to check against (defaults to self.mesh)

        Raises:
            ValueError: If any probe is outside the mesh bounds

        Note:
            This performs a bounding box check first, then attempts to create
            a VertexOnlyMesh to verify Firedrake can locate the points.
        """
        import logging

        if mesh is None:
            mesh = self.mesh

        probes_array = np.asarray(probes)
        if len(probes_array) == 0:
            return  # No probes to validate

        # Get mesh coordinates for bounding box check
        coords = mesh.coordinates.dat.data_ro
        x_min, y_min = coords.min(axis=0)
        x_max, y_max = coords.max(axis=0)

        # Check if any probes are outside bounding box
        outside_probes = []
        for i, (x, y) in enumerate(probes_array):
            if x < x_min or x > x_max or y < y_min or y > y_max:
                outside_probes.append((i, x, y))

        if outside_probes:
            msg = f"Found {len(outside_probes)} probe(s) outside mesh bounds:\n"
            msg += f"  Mesh bounds: x ∈ [{x_min:.3f}, {x_max:.3f}], y ∈ [{y_min:.3f}, {y_max:.3f}]\n"
            for idx, x, y in outside_probes[:5]:  # Show first 5
                msg += f"  Probe {idx}: ({x:.3f}, {y:.3f})\n"
            if len(outside_probes) > 5:
                msg += f"  ... and {len(outside_probes) - 5} more\n"
            logging.log(logging.ERROR, msg)
            raise ValueError(msg)

        # Try to create VertexOnlyMesh to verify Firedrake can locate the points
        # This is a more accurate test than bounding box alone
        try:
            _ = fd.VertexOnlyMesh(mesh, probes_array)
            # If we got here, all points were successfully located
        except Exception as e:
            msg = f"Failed to locate probe points in mesh: {e}\n"
            msg += "This may indicate probes are outside the mesh or in excluded regions."
            raise ValueError(msg) from e

    def velocity_probe(self, probes, q: fd.Function = None) -> list[float]:
        """Probe velocity in the wake.

        Returns a list of velocities at the probe locations, ordered as
        (u1, u2, ..., uN, v1, v2, ..., vN) where N is the number of probes.
        """
        if q is None:
            q = self.q
        u = q.subfunctions[0]
        probes_array = np.asarray(probes)
        # Get mesh from the main mixed space (self.q has mesh info)
        mesh = self.mesh
        # Create VertexOnlyMesh at probe locations and interpolate
        vom = fd.VertexOnlyMesh(mesh, probes_array)
        V_vom = fd.VectorFunctionSpace(vom, "DG", 0)
        u_vom = fd.Function(V_vom)
        u_vom.interpolate(u)
        # Extract values and return in expected format
        return u_vom.dat.data_ro.flatten("F")

    def pressure_probe(self, probes, q: fd.Function = None) -> list[float]:
        """Probe pressure around the cylinder"""
        if q is None:
            q = self.q
        p = q.subfunctions[1]
        probes_array = np.asarray(probes)
        # Get mesh from the main mixed space
        mesh = self.mesh
        # Create VertexOnlyMesh at probe locations and interpolate
        vom = fd.VertexOnlyMesh(mesh, probes_array)
        P_vom = fd.FunctionSpace(vom, "DG", 0)
        p_vom = fd.Function(P_vom)
        p_vom.interpolate(p)
        # Extract values and return
        return p_vom.dat.data_ro

    def vorticity_probe(self, probes, q: fd.Function = None) -> list[float]:
        """Probe vorticity in the wake."""
        if q is None:
            u = None
        else:
            u = q.subfunctions[0]
        vort = self.vorticity(u=u)
        probes_array = np.asarray(probes)
        # Get mesh from the main mixed space
        mesh = self.mesh
        # Create VertexOnlyMesh at probe locations and interpolate
        vom = fd.VertexOnlyMesh(mesh, probes_array)
        V_vom = fd.FunctionSpace(vom, "DG", 0)
        vort_vom = fd.Function(V_vom)
        vort_vom.interpolate(vort)
        # Extract values and return
        return vort_vom.dat.data_ro

    def linearize(self, qB=None, adjoint=False, sigma=0.0, inverse=False, solver_parameters=None):
        if sigma != 0.0 and not inverse:
            raise ValueError("Must use `inverse=True` with spectral shift.")

        if qB is None:
            qB = self.q

        if not inverse:
            return self._jacobian_operator(qB, adjoint=adjoint)

        if sigma.imag == 0.0:
            return self._real_shift_inv_operator(qB, sigma, adjoint=adjoint, solver_parameters=solver_parameters)

        return self._complex_shift_inv_operator(qB, sigma, adjoint=adjoint, solver_parameters=solver_parameters)

    # TODO: Test this. This is just here as an extension of the work done with
    # shift-inverse-type operators, but hasn't been directly tested yet. Really
    # it should be used for linearized time-stepping.
    def _jacobian_operator(self, qB, adjoint=False):
        """Construct the Jacobian operator for the Navier-Stokes equations.

        A matrix-vector product for this operator is equivalent to evaluating
        the Jacobian of the Navier-Stokes equations at a given state.
        """
        # Set up function spaces
        fn_space = self.mixed_space
        (uB, pB) = fd.split(qB)
        q_trial = fd.TrialFunction(fn_space)
        q_test = fd.TestFunction(fn_space)
        (v, s) = fd.split(q_test)

        # Collect boundary conditions
        self.linearize_bcs()
        bcs = self.collect_bcs()

        # Linear form expressing the RHS of the Navier-Stokes without time derivative
        # For a steady solution this is F(qB) = 0.
        F = self.residual((uB, pB), q_test=(v, s))

        # The Jacobian of F is the bilinear form J(qB, q_test) = dF/dq(qB) @ q_test
        J = fd.derivative(F, qB, q_trial)

        A = DirectOperator(J, bcs, fn_space)

        if adjoint:
            A = A.T

        return A

    def _real_shift_inv_operator(self, qB, sigma, adjoint=False, solver_parameters=None):
        """Construct a shift-inverse Arnoldi iterator with real (or zero) shift.

        The shift-inverse iteration solves the matrix pencil
        (J - sigma * M) @ v1 = M @ v0 for v1, where J is the Jacobian of the
        Navier-Stokes equations, and M is the mass matrix.
        """
        fn_space = self.mixed_space
        (uB, pB) = fd.split(qB)
        q_trial = fd.TrialFunction(fn_space)
        q_test = fd.TestFunction(fn_space)
        (v, s) = fd.split(q_test)

        # Collect boundary conditions
        self.linearize_bcs()
        bcs = self.collect_bcs()

        def M(q):
            """Mass matrix for the Navier-Stokes equations"""
            return self.inner_product(q, q_test, assemble=False)

        # Linear form expressing the RHS of the Navier-Stokes without time derivative
        # For a steady solution this is F(qB) = 0.
        F = self.residual((uB, pB), q_test=(v, s))

        if sigma != 0.0:
            F -= sigma * M(qB)

        # The Jacobian of F is the bilinear form J(qB, q_test) = dF/dq(qB) @ q_test
        J = fd.derivative(F, qB, q_trial)

        A = InverseOperator(J, M, bcs, fn_space, solver_parameters)

        if adjoint:
            A = A.T

        return A

    def _complex_shift_inv_operator(self, qB, sigma, adjoint=False, solver_parameters=None):
        """Construct a shift-inverse Arnoldi iterator with complex-valued shift.

        The shifted operator is `A = (J - sigma * M)`

        For sigma = (sr, si), the real and imaginary parts of A are
        A = (J - sr * M, -si * M)
        The system solve is A @ v1 = M @ v0, so for complex vectors v = (vr, vi):
        (Ar + 1j * Ai) @ (v1r + 1j * v1i) = M @ (v0r + 1j * v0i)
        Since we can't do complex analysis without re-building PETSc, instead we treat this
        as a block system:
        ```
        [Ar,   Ai]  [v1r]  = [M 0]  [v0r]
        [-Ai,  Ar]  [v1i]    [0 M]  [v0i]
        ```

        Note that this will be more expensive than real- or zero-shifted iteration,
        since there are twice as many degrees of freedom.  However, it will tend to
        converge faster for the eigenvalues of interest.

        The shift-inverse iteration solves the matrix pencil
        (J - sigma * M) @ v1 = M @ v0 for v1, where J is the Jacobian of the
        Navier-Stokes equations, and M is the mass matrix.
        """
        fn_space = self.mixed_space
        W = fn_space * fn_space
        V1, Q1, V2, Q2 = W

        # Set the boundary conditions for each function space
        # These will be identical
        self.linearize_bcs(function_spaces=(V1, Q1))
        bcs1 = self.collect_bcs()

        self.linearize_bcs(function_spaces=(V2, Q2))
        bcs2 = self.collect_bcs()

        bcs = [*bcs1, *bcs2]

        # Since the base flow is used to construct the Navier-Stokes Jacobian
        # which is used on the diagonal block for both real and imaginary components,
        # we have to duplicate the base flow for both components.  This does NOT
        # mean that the base flow literally has an imaginary component
        qB_aug = fd.Function(W)
        uB_re, pB_re, uB_im, pB_im = fd.split(qB_aug)
        qB_aug.subfunctions[0].interpolate(qB.subfunctions[0])
        qB_aug.subfunctions[1].interpolate(qB.subfunctions[1])
        qB_aug.subfunctions[2].interpolate(qB.subfunctions[0])
        qB_aug.subfunctions[3].interpolate(qB.subfunctions[1])

        # Create trial and test functions
        q_trial = fd.TrialFunction(W)
        q_test = fd.TestFunction(W)
        (v_re, s_re, v_im, s_im) = fd.split(q_test)

        # Construct the nonlinear residual for the Navier-Stokes equations
        F_re = self.residual((uB_re, pB_re), q_test=(v_re, s_re))
        F_im = self.residual((uB_im, pB_im), q_test=(v_im, s_im))

        def _inner(u, v):
            return ufl.inner(u, v) * ufl.dx

        # Shift each block of the linear form appropriately
        F11 = F_re - sigma.real * _inner(uB_re, v_re)
        F22 = F_im - sigma.real * _inner(uB_im, v_im)
        F12 = sigma.imag * _inner(uB_im, v_re)
        F21 = -sigma.imag * _inner(uB_re, v_im)
        F = F11 + F22 + F12 + F21

        # Differentiate to get the bilinear form for the Jacobian
        J = fd.derivative(F, qB_aug, q_trial)

        def M(q):
            """Mass matrix for the Navier-Stokes equations"""
            return self.inner_product(q, q_test, assemble=False, augmented=True)

        A = InverseOperator(J, M, bcs, W, solver_parameters)

        if adjoint:
            A = A.T

        return A
